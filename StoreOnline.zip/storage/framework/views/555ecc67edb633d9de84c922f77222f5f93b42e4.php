

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('')); ?></div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <?php echo e(__('You are logged in!')); ?>

                    </div>
                    <div>
                        <?php if(!empty($allprod)): ?>
                            <?php $__currentLoopData = $allprod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allproduc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <section class="page-section">
                                    <div class="container">
                                        <div class="product-item">
                                            <div class="product-item-title d-flex">
                                                <div class="bg-faded p-5 d-flex ml-auto rounded">
                                                    <h2 class="section-heading mb-0">

                                                        <span class="section-heading-upper"><?= $allproduc->name ?>
                                                                <button onclick="window.location='/client/<?= $allproduc->id ?>/buy'" name="buy" method='get' type="button" class="btn btn-primary">Comprar</button>
                                                              </span>
                                                              <span class="section-heading-lower"><?= $allproduc->category->name ?> - S/<?= $allproduc->price ?>
                                                              </span>

                                                            </h2>
                                                          </div>

                                                        </div>
                                                          <img class="product-item-img mx-auto d-flex rounded  mb-3 mb-lg-0" src="uploads/products/img/<?= $allproduc->image ?>" alt=""  width="596" height="460"/>
                                                          <div class="product-item-description d-flex mr-auto">
                                                            <div class="bg-faded p-5 rounded">
                                                              <h2 class="section-heading mb-4">
                                                                <span class="section-heading-lower">Descripción</span>
                                                              </h2>
                                                                <p class="mb-0"><?= $allproduc['description'] ?></p>
                                                            </div>
                                                          </div>
                                                      </div>
                                                    </div>
                                                  </section>
                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php else: ?>
                                                    <h1 class="text-center navbar-nav mx-auto " >

                                                      No hay productos
                                                    </h1>

                                                  <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\StoreOnline\resources\views/clientComponent/client.blade.php ENDPATH**/ ?>