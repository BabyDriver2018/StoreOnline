<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>LEYKER</title>

    <!-- Bootstrap core CSS -->
    <link type="text/css" href="<?php echo e(asset('bootstrap/css/bootstrap.css')); ?>" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link
        href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i" rel="stylesheet">
    
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
        integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <!-- Custom styles for this template -->
    <link type="text/css" href="<?php echo e(asset('css/business-casual.css')); ?>" rel="stylesheet">

</head>

<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark py-lg-4" id="mainNav">
        <div class="container">
            <a class="navbar-brand text-uppercase text-expanded font-weight-bold d-lg-none"
                href="<?php echo e(url('/home')); ?>">LEYKER</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive"
                aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item px-lg-4">
                        <a class="nav-link text-uppercase text-expanded" href="<?php echo e(url('/home')); ?>">Inicio
                            <span class="sr-only">(current)</span>
                        </a>
                    </li>
                    <li class="nav-item px-lg-4">
                        <a class="nav-link text-uppercase text-expanded" href="<?php echo e(url('/registerVent')); ?>">Registro
                            de
                            Ventas</a>
                    </li>
                    <li class="nav-item active px-lg-4">
                        <a class="nav-link text-uppercase text-expanded" href="<?php echo e(url('/products')); ?>">Productos</a>
                    </li>
                    <li class="nav-item px-lg-4">
                        <a class="nav-link text-uppercase text-expanded" href="<?php echo e(url('/store')); ?>">Tienda</a>
                    </li>
                    <li class="nav-item px-lg-4">
                        <a class="nav-link text-uppercase text-expanded" href="<?php echo e(url('/addproducts')); ?>">Agregar
                            Productos</a>
                    </li>
                    <a class="nav-item px-lg-4" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                       document.getElementById('logout-form').submit();">
                        <?php echo e(__('Cerrar Sesión')); ?>

                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </ul>
            </div>
        </div>
    </nav>

    <section class="page-section cta">
        <div class="container">
            <div class="row">
                <div class="col-xl-9 mx-auto">
                    <div class="cta-inner text-center rounded">
                        <h2 class="section-heading mb-7">
                            <span class="section-heading-upper">Editar Producto</span>
                        </h2>
                        <ul class="list-unstyled list-hours mb-5 text-left mx-auto">
                            <form action="<?php echo e(url('/products/edit')); ?>" method="post"
                                class="form-horizontal" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('PATCH')); ?>

                                <?php echo e(method_field('POST')); ?>

                                <div class="form-group">
                                    <label class="control-label col-sm-2">Categoria:</label>
                                    <div class="col-sm-10">
                                        <input class="form-check-input" type="radio" name="category" id="category" value="1" checked>
                                        <label class="form-check-label" for="exampleRadios1">
                                            Hombre
                                        </label>
                                    </div>
                                    <div class="col-sm-10">
                                        <input class="form-check-input" type="radio" name="category" id="category" value="2" checked>
                                        <label class="form-check-label" for="exampleRadios1">
                                            Mujer
                                        </label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-2">Nombre:</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="name"
                                            placeholder="Nombre del Producto" required minlength="3" value="<?=$oneprod['name']?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-2">Descripcion:</label>
                                    <div class="col-sm-10">
                                        <textarea class="form-control" name="description" rows="3" required
                                            minlength="10" placeholder="Descripcion del Producto" ><?=$oneprod['description']?></textarea>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-2">Price:</label>
                                    <div class="col-sm-10">
                                        <input type="number" min="1" class="form-control" name="price"
                                            placeholder="Ingrese su precio" pattern="[0-9]{1,2}" value="<?=$oneprod['price']?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-sm-2">Stock:</label>
                                    <div class="col-sm-10">
                                        <input type="number" min="1" class="form-control" name="stock"
                                            placeholder="Ingrese su stock" pattern="[0-9]{1,2}" value="<?=$oneprod['stock']?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="image">Imagen Actual</label>
                                    <img class="product-item-img mx-auto d-flex rounded  mb-3 mb-lg-0" src="../uploads/products/img/<?= $oneprod['image'] ?>" alt="" width="200" height="140"/>
                                    <label for="image">Editar Imagen</label>
                                    <input type="file" class="form-control-file" id="image" name="image" accept="image/*">
                                </div>

                                <div class="form-group mt-3">
                                    <div class="col-sm-offset-2 col-sm-10">
                                        <button type="submit" name="product" value="<?= $oneprod['id']?>" class="btn btn-primary">Agregar Cambios del producto</button>
                                    </div>
                                </div>
                            </form>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>


<footer class="footer text-faded text-center py-5">
  <div class="container">
    <p class="m-0 small">Copyright &copy; Your Website 2020</p>
  </div>
  <!-- Footer Social Icons -->
  <div class="container">
    <a href="https://www.facebook.com/LeykerPeru/">
        <h4 class="text-uppercase mb-4">Cuenta Oficial de Facebook</h4>
    </a>

</div>
</footer>

<!-- Bootstrap core JavaScript -->
<script src="<?php echo e(asset('jquery/jquery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('bootstrap/js/bootstrap.bundle.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\StoreOnline\resources\views/prodEditComponent/edit.blade.php ENDPATH**/ ?>